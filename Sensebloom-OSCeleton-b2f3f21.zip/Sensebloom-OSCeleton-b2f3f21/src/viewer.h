#include <XnCppWrapper.h>

extern xn::DepthMetaData depthMD;

void init_window(int, char**, int, int, void(void));
void draw();
