#ifdef WIN32
#include <windows.h>
#include "gl\glut.h"
#else
#include <GL/glut.h>
#endif

extern int window;

#include "viewer.h"
